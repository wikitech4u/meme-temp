module.exports = [
"[project]/src/components/custom/floating-images.tsx [app-rsc] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/src_components_custom_floating-images_tsx_7a991cd1._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/custom/floating-images.tsx [app-rsc] (ecmascript, next/dynamic entry)");
    });
});
}),
];