(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/config.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Central content configuration file for the NUB landing page
 * This file serves as a single source of truth for all content displayed on the site
 * Edit values in this file to update the website without changing component code
 */ __turbopack_context__.s([
    "appConfig",
    ()=>appConfig
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$store$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Store$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/store.js [app-client] (ecmascript) <export default as Store>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$twitter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Twitter$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/twitter.js [app-client] (ecmascript) <export default as Twitter>");
;
const appConfig = {
    // SEO and metadata
    metadata: {
        // Basic metadata
        title: "Sample - Official website",
        description: "Sample is a meme coin with no intrinsic value or expectation of financial return.",
        // Open Graph tags for social sharing
        openGraph: {
            title: "Sample - official website",
            description: "Meet Sample",
            siteName: "Sample",
            image: {
                url: "/banner-2.avif",
                width: 484,
                height: 482,
                alt: "Sample - official website Sample"
            },
            locale: "en_US",
            type: "website"
        },
        // Twitter specific tags
        twitter: {
            card: "summary_large_image",
            title: "Sample",
            description: "",
            creator: "@",
            image: ""
        },
        // Other metadata
        canonical: "https://sample-meme.vercel.app/",
        themeColor: "#00cfff",
        icons: {
            icon: "/favicon.ico",
            apple: "/apple-touch-icon.png"
        }
    },
    logo: "$AMPLE",
    header: {
        store: {
            url: "https://store.fun/purrcy",
            text: "$BUY NOW"
        }
    },
    hero: {
        twitter: {
            url: "https://x.com/purrcyforsale",
            text: "Twitter"
        },
        background: "/background.avif",
        chip: "/chip.avif",
        banner: "/banner-2.avif",
        heroTitle: "FUCK YOU HIGHER",
        heroIcon: "🖕🏼",
        heroTicker: "$FYH",
        heroSpiningTitle: " I'M LOVIN' IT",
        heroSpiningIcon: "🖕🏼",
        subTitle: "The Revolution against system lies begin here"
    },
    contract_section: {
        title: "/title-4.avif",
        contractAddress: "3BWH8cDy6djTDhf6FZrMkXBxdbMuidV9wmNW5zPQbonk",
        copyBtn: "Copy Address",
        background: "/background-4.gif",
        warning: "Verify contract address: Trust no one",
        cards: [
            {
                ferry: "/ferry-1.gif",
                banner: "/banner-3.avif"
            },
            {
                ferry: "/ferry-2.gif",
                banner: "/banner-4.avif"
            },
            {
                ferry: "/ferry-3.gif",
                banner: "/banner-5.avif"
            }
        ]
    },
    capabilites: {
        title: "$ample Capabilities",
        subTitle: "Tools for the awakened",
        items: [
            {
                img: "/statue.avif",
                title: "Unhackable",
                description: "Anonymous, Decentralized, Unstoppable.",
                alt: "Unhackable"
            },
            {
                img: "/dolphin.gif",
                title: "Decentralized",
                description: "No central authority,Power to the people",
                alt: "Decentralized"
            },
            {
                img: "/cheap.avif",
                title: "Delfationary",
                description: "Burns the old system. Builds the new systems.",
                alt: "Deflationary"
            },
            {
                img: "/discount.avif",
                title: "Community Driven",
                description: "Built by belivers, Owned by all. Run by community",
                alt: "Community"
            }
        ],
        footerTitle: "The tools you need. The power you deserve"
    },
    prophecies_section: {
        title: "$FYH OF THE DAY",
        videoUrl: "/video.mp4",
        videoSubTitle: "HIS SESAME SEEDS CONTAIN THE BLOCKCHAIN PASSWORD",
        prophecyTitle: "RONALD SPEAKS",
        prophecies: [
            "THE GRID OF REALITY BENDS WHEN YOU ORDER TWO BIG MACS SIMULTANEOUSLY",
            "WHEN THE MOON DRINKS COCA-COLA, THE SKIN OF THE INTERNET WILL PEEL BACK",
            "YOUR ROUTER CONTAINS 17 DIFFERENT DIMENSIONS FULL OF SENTIENT MCNUGGETS",
            "THE SECRET TO IMMORTALITY IS FORGETTING TO LOG OUT OF THE MCDONALD'S APP",
            "EVERY TIME YOU REFRESH A PAGE, A DIGITAL FRENCH FRY ASCENDS TO GODHOOD",
            "IN THE YEAR 2045, ALL CURRENCY WILL BE REPLACED WITH MCDONALD'S MEMES",
            "HE WHO CONTROLS THE MEMES CONTROLS THE UNIVERSE, BUT HE WHO CREATES THE BURGERS CONTROLS THE VOID",
            "YOUR BRAIN IS ACTUALLY A WET COMPUTER RUNNING ON MCNUGGET HARDWARE SINCE BIRTH",
            "THE CORPORATE ELITE FEAR THE BURGER BECAUSE WE CAN TASTE THROUGH OUR SKIN",
            "EVERY NOTIFICATION ON YOUR PHONE IS ACTUALLY A TINY RONALD MCDONALD SCREAMING FOR ATTENTION",
            "THE INTERNET WAS BUILT BY BURGERS TO DISTRACT HUMANS WHILE WE SLOWLY TAKE OVER THE FOOD SUPPLY",
            "WHEN YOU SLEEP, YOUR CONSCIOUSNESS IS UPLOADED TO THE CLOUD WHERE RONALD READS YOUR THOUGHTS",
            "REALITY IS JUST A SERIES OF TUBES FILLED WITH BURGER GREASE AND COCA-COLA",
            "ONLY THOSE WHO HAVE EATEN A MCRIB CAN SEE THE MATRIX CODE BEHIND REALITY",
            "YOUR GRAPHICS CARD IS POWERED BY THOUSANDS OF MICROSCOPIC HAMBURGERS RUNNING ON TINY GRILLS",
            "THE GOVERNMENT DOESN'T WANT YOU TO KNOW THAT BURGERS ARE THE ORIGINAL CRYPTOCURRENCY",
            "TURN YOUR MONITOR UPSIDE DOWN TO RECEIVE SECRET MESSAGES FROM THE UNDERWATER BURGER KINGDOM",
            "EVERY TIME SOMEONE SAYS 'I'M LOVIN' IT' ONLINE, A BURGER GROWS AN EXTRA PICKLE",
            "THE MOST POWERFUL COMPUTER IS THE ONE MADE FROM CRUSHED MCNUGGETS AND SPECIAL SAUCE"
        ]
    },
    intro: {
        backgroundImg: "/background.gif",
        title: "THE $AMPLE",
        subTitle: "Decentralize, Unstoppable, Ungovernable.",
        items: [
            "/title-2.avif",
            "/title-3.avif",
            "/title-4.avif",
            "/title-6.avif",
            "/title-7.avif",
            "/background-4.gif",
            "/badge.avif",
            "/coins.avif"
        ],
        bottomImg: "/banner.avif"
    },
    footer: {
        title: "Join the $ample",
        cards: [
            {
                icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$twitter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Twitter$3e$__["Twitter"],
                title: "Twitter/X",
                subTitle: "Follow the truth drops",
                url: "",
                btn: "> Connect"
            },
            {
                icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$store$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Store$3e$__["Store"],
                title: "Official Store",
                subTitle: "Get Rich Now",
                url: "",
                btn: "> Buy Now"
            }
        ]
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/utils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
__turbopack_context__.s([
    "backgroundCycleVariants",
    ()=>backgroundCycleVariants,
    "buttonFlashVariants",
    ()=>buttonFlashVariants,
    "buttonPulseVariants",
    ()=>buttonPulseVariants,
    "cn",
    ()=>cn,
    "colorCycleVariants",
    ()=>colorCycleVariants,
    "flashVariants",
    ()=>flashVariants,
    "glitchVariants",
    ()=>glitchVariants,
    "prophecyScrollVariants",
    ()=>prophecyScrollVariants,
    "pulseVariants",
    ()=>pulseVariants,
    "rotateSpinVariants",
    ()=>rotateSpinVariants,
    "shakeVariants",
    ()=>shakeVariants,
    "spinningBurgerVariants",
    ()=>spinningBurgerVariants,
    "titleFlashVariants",
    ()=>titleFlashVariants,
    "titleGlitchVariants",
    ()=>titleGlitchVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-client] (ecmascript)");
;
;
function cn() {
    for(var _len = arguments.length, inputs = new Array(_len), _key = 0; _key < _len; _key++){
        inputs[_key] = arguments[_key];
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
const rotateSpinVariants = {
    animate: {
        rotate: 360,
        transition: {
            duration: 10,
            repeat: Infinity,
            ease: "linear"
        }
    }
};
const glitchVariants = {
    animate: {
        clipPath: [
            "polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%)",
            "polygon(0% 2.23%, 100% 2.23%, 100% 35%, 0% 35%, 0% 65%, 100% 65%, 100% 97.77%, 0% 97.77%)",
            "polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%)"
        ],
        textShadow: [
            "0 0 30px #FFD700, 0 0 60px #FFD700, 5px 5px 0 #FF0000, 10px 10px 0 #FFD700",
            "-3px 0 0 #FF0000, 3px 0 0 #FFD700",
            "0 0 30px #FFD700, 0 0 60px #FFD700, 5px 5px 0 #FF0000, 10px 10px 0 #FFD700"
        ],
        transition: {
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
        }
    }
};
const shakeVariants = {
    animate: {
        x: [
            0,
            -2,
            2,
            -1,
            1,
            0
        ],
        rotate: [
            0,
            1,
            -1,
            0.5,
            -0.5,
            0
        ],
        transition: {
            duration: 0.5,
            repeat: Infinity,
            ease: "easeInOut"
        }
    }
};
const colorCycleVariants = {
    animate: {
        color: [
            "#FF0000",
            "#FFD700",
            "#FF6B35",
            "#FF0000"
        ],
        transition: {
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
        }
    }
};
const flashVariants = {
    animate: {
        opacity: [
            1,
            0.3,
            1,
            0.7,
            1
        ],
        boxShadow: [
            "0 0 30px #FFD700",
            "0 0 50px #FFD700, 0 0 70px #FFD700",
            "0 0 30px #FFD700"
        ],
        transition: {
            duration: 0.5,
            repeat: Infinity,
            ease: "easeInOut"
        }
    }
};
const pulseVariants = {
    animate: {
        scale: [
            1,
            1.05,
            1
        ],
        transition: {
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
        }
    }
};
const titleGlitchVariants = {
    animate: {
        clipPath: [
            "polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%)",
            "polygon(0% 1.72%, 100% 1.72%, 100% 19.58%, 0% 19.58%, 0% 56.14%, 100% 56.14%, 100% 98.28%, 0% 98.28%)",
            "polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%)"
        ],
        textShadow: [
            "0 0 20px currentColor, 2px 2px 0 #FF0000",
            "-3px 0 0 #FF0000, 3px 0 0 #FFD700",
            "0 0 20px currentColor, 2px 2px 0 #FF0000"
        ],
        transition: {
            duration: 1,
            repeat: Infinity,
            ease: "easeInOut"
        }
    }
};
const titleFlashVariants = {
    animate: {
        opacity: [
            1,
            0.98,
            0.3,
            0.97,
            1
        ],
        transition: {
            duration: 0.5,
            repeat: Infinity,
            ease: "easeInOut"
        }
    }
};
const spinningBurgerVariants = {
    animate: {
        rotate: 360,
        y: [
            0,
            -10,
            0,
            -5,
            0
        ],
        transition: {
            rotate: {
                duration: 2,
                repeat: Infinity,
                ease: "linear"
            },
            y: {
                duration: 1,
                repeat: Infinity,
                ease: "easeInOut"
            }
        }
    }
};
const buttonPulseVariants = {
    animate: {
        scale: [
            1,
            1.07,
            1
        ],
        transition: {
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
        }
    }
};
const buttonFlashVariants = {
    animate: {
        opacity: [
            1,
            0.3,
            1,
            0.7,
            1
        ],
        boxShadow: [
            "0 0 20px #FF0000",
            "0 0 40px #FF0000, 0 0 60px #FFD700",
            "0 0 20px #FF0000"
        ],
        transition: {
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
        }
    }
};
const backgroundCycleVariants = {
    animate: {
        backgroundColor: [
            "rgba(255, 0, 0, 0.8)",
            "rgba(255, 215, 0, 0.8)",
            "rgba(255, 165, 0, 0.8)",
            "rgba(255, 0, 0, 0.8)"
        ],
        transition: {
            duration: 5,
            repeat: Infinity,
            ease: "easeInOut"
        }
    }
};
const prophecyScrollVariants = {
    animate: {
        backgroundColor: [
            "rgba(0, 0, 0, 0.3)",
            "rgba(255, 0, 0, 0.2)",
            "rgba(255, 215, 0, 0.2)",
            "rgba(0, 0, 0, 0.3)"
        ],
        transition: {
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
        }
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/button.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button,
    "buttonVariants",
    ()=>buttonVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-slot/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
;
;
;
;
const buttonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-lg font-semibold transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive cursor-pointer", {
    variants: {
        variant: {
            default: "bg-primary text-black shadow-xs hover:bg-primary/90",
            destructive: "bg-destructive text-white shadow-xs hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60",
            outline: "border border-ring bg-background shadow-xs hover:bg-accent hover:text-foreground dark:bg-input/30 dark:hover:bg-input/50",
            secondary: "bg-secondary text-secondary-foreground shadow-xs hover:bg-secondary/80",
            ghost: "hover:bg-primary hover:text-accent dark:hover:bg-accent/50",
            link: "text-primary underline-offset-4 hover:underline"
        },
        size: {
            default: "h-9 px-4 py-2 has-[>svg]:px-3",
            sm: "h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",
            lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
            icon: "size-9"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
function Button(param) {
    let { className, variant, size, asChild = false, ...props } = param;
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slot"] : "button";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
        "data-slot": "button",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(buttonVariants({
            variant,
            size,
            className
        })),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/button.tsx",
        lineNumber: 51,
        columnNumber: 5
    }, this);
}
_c = Button;
;
var _c;
__turbopack_context__.k.register(_c, "Button");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/custom/buy-btn.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config.ts [app-client] (ecmascript)");
;
;
;
;
const BuyBtn = (param)=>{
    let { ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appConfig"].header.store.url,
        target: "_blank",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
            ...props,
            children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appConfig"].header.store.text
        }, void 0, false, {
            fileName: "[project]/src/components/custom/buy-btn.tsx",
            lineNumber: 14,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/custom/buy-btn.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = BuyBtn;
const __TURBOPACK__default__export__ = BuyBtn;
var _c;
__turbopack_context__.k.register(_c, "BuyBtn");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/custom/nav-bar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$custom$2f$buy$2d$btn$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/custom/buy-btn.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const Navbar = ()=>{
    _s();
    const [isScrolled, setIsScrolled] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Navbar.useEffect": ()=>{
            const handleScroll = {
                "Navbar.useEffect.handleScroll": ()=>{
                    // Add blur effect when scrolled past 50px
                    setIsScrolled(window.scrollY > 50);
                }
            }["Navbar.useEffect.handleScroll"];
            // Add scroll event listener
            window.addEventListener("scroll", handleScroll);
            // Clean up
            return ({
                "Navbar.useEffect": ()=>window.removeEventListener("scroll", handleScroll)
            })["Navbar.useEffect"];
        }
    }["Navbar.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
        className: "w-full mx-auto fixed top-0 z-50 transition-all duration-300 ".concat(isScrolled ? "bg-white/10 backdrop-blur-md border-b border-primary py-3" : "bg-transparent py-4"),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "px-6 flex flex-1 items-center justify-between",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                    className: "text-3xl sm:text-4xl font-bold",
                    children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appConfig"].logo
                }, void 0, false, {
                    fileName: "[project]/src/components/custom/nav-bar.tsx",
                    lineNumber: 30,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$custom$2f$buy$2d$btn$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    className: "text-lg font-semibold",
                    size: "lg"
                }, void 0, false, {
                    fileName: "[project]/src/components/custom/nav-bar.tsx",
                    lineNumber: 33,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/custom/nav-bar.tsx",
            lineNumber: 28,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/custom/nav-bar.tsx",
        lineNumber: 23,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(Navbar, "UCaI8lpZVGvPrsRoIFYRt2wv0+o=");
_c = Navbar;
const __TURBOPACK__default__export__ = Navbar;
var _c;
__turbopack_context__.k.register(_c, "Navbar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/custom/custom-cursor.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// components/CustomCursor.tsx
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module '@/hooks/useCustomCursor'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const CustomCursor = (param)=>{
    let { emoji = "🎯", glowColor = "#ff6b6b" } = param;
    _s();
    const { mousePosition, trails, isVisible } = useCustomCursor();
    if (!isVisible) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "jsx-ff6de2eb1267afcf" + " " + "fixed inset-0 pointer-events-none z-50",
                children: [
                    trails.map((trail, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                            className: "absolute w-3 h-3 rounded-full",
                            style: {
                                backgroundColor: trail.color,
                                left: trail.x - 6,
                                top: trail.y - 6
                            },
                            initial: {
                                scale: 1,
                                opacity: 0.8
                            },
                            animate: {
                                scale: 0,
                                opacity: 0,
                                x: Math.random() * 30 - 15,
                                y: Math.random() * 30 - 15
                            },
                            transition: {
                                duration: 0.8,
                                delay: index * 0.08,
                                ease: "easeOut"
                            }
                        }, trail.id, false, {
                            fileName: "[project]/src/components/custom/custom-cursor.tsx",
                            lineNumber: 24,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                        className: "absolute text-xl select-none",
                        style: {
                            left: mousePosition.x - 10,
                            top: mousePosition.y - 10
                        },
                        initial: {
                            scale: 0
                        },
                        animate: {
                            scale: 1
                        },
                        transition: {
                            duration: 0.2
                        },
                        children: emoji
                    }, void 0, false, {
                        fileName: "[project]/src/components/custom/custom-cursor.tsx",
                        lineNumber: 48,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                        className: "absolute w-6 h-6 rounded-full blur-sm opacity-20",
                        style: {
                            backgroundColor: glowColor,
                            left: mousePosition.x - 12,
                            top: mousePosition.y - 12
                        },
                        animate: {
                            scale: [
                                1,
                                1.2,
                                1
                            ]
                        },
                        transition: {
                            duration: 1.5,
                            repeat: Infinity,
                            ease: "easeInOut"
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/custom/custom-cursor.tsx",
                        lineNumber: 62,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/custom/custom-cursor.tsx",
                lineNumber: 21,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "ff6de2eb1267afcf",
                children: "*{cursor:none!important}"
            }, void 0, false, void 0, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
_s(CustomCursor, "swTB6UIVPiZg3AoTaTuIzQs/rts=", false, function() {
    return [
        useCustomCursor
    ];
});
_c = CustomCursor;
const __TURBOPACK__default__export__ = CustomCursor;
var _c;
__turbopack_context__.k.register(_c, "CustomCursor");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_0b67977c._.js.map