(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__6832caa9._.css",
  "static/chunks/node_modules_cb4529f3._.js",
  "static/chunks/src_93482d09._.js"
],
    source: "dynamic"
});
