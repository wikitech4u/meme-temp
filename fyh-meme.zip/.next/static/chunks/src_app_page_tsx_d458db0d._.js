(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_c7c51ad2._.js",
  "static/chunks/src_components_custom_4793d3d1._.js"
],
    source: "dynamic"
});
