(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/custom/floating-images.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FloatingSquares
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const images = [
    {
        src: "float-1.webp",
        alt: "FLOATING MCDC SQUARE 1"
    },
    {
        src: "float-2.webp",
        alt: "FLOATING MCDC SQUARE 2"
    },
    {
        src: "float-3.avif",
        alt: "FLOATING MCDC SQUARE 3"
    },
    {
        src: "float-4.avif",
        alt: "FLOATING MCDC SQUARE 4"
    },
    {
        src: "float-5.webp",
        alt: "FLOATING MCDC SQUARE 5"
    },
    {
        src: "float-6.webp",
        alt: "FLOATING MCDC SQUARE 6"
    },
    {
        src: "float-7.avif",
        alt: "FLOATING MCDC SQUARE 7"
    }
];
function FloatingSquares() {
    _s();
    const [positions, setPositions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FloatingSquares.useEffect": ()=>{
            const newPositions = images.map({
                "FloatingSquares.useEffect.newPositions": ()=>({
                        left: Math.random() * window.innerWidth,
                        top: Math.random() * window.innerHeight,
                        rotate: Math.random() * 7200 - 3600,
                        scale: 0.6 + Math.random() * 0.4,
                        filter: "hue-rotate(".concat(Math.random() * 360, "deg) saturate(2.5) contrast(1.3) brightness(1.1)")
                    })
            }["FloatingSquares.useEffect.newPositions"]);
            setPositions(newPositions);
        }
    }["FloatingSquares.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed top-0 left-0 w-full h-full pointer-events-none z-50 overflow-hidden",
        children: positions.length > 0 && images.map((img, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                className: "absolute",
                style: {
                    left: positions[i].left,
                    top: positions[i].top,
                    rotate: "".concat(positions[i].rotate, "deg"),
                    scale: positions[i].scale,
                    filter: positions[i].filter
                },
                animate: {
                    y: [
                        0,
                        -20,
                        0
                    ],
                    scale: [
                        positions[i].scale,
                        positions[i].scale * 1.05,
                        positions[i].scale
                    ],
                    rotate: [
                        0,
                        360
                    ]
                },
                transition: {
                    duration: 10 + Math.random() * 10,
                    repeat: Infinity,
                    ease: "easeInOut"
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    src: img.src,
                    alt: img.alt,
                    width: 150,
                    height: 150,
                    className: "rounded-lg"
                }, void 0, false, {
                    fileName: "[project]/src/components/custom/floating-images.tsx",
                    lineNumber: 70,
                    columnNumber: 13
                }, this)
            }, i, false, {
                fileName: "[project]/src/components/custom/floating-images.tsx",
                lineNumber: 45,
                columnNumber: 11
            }, this))
    }, void 0, false, {
        fileName: "[project]/src/components/custom/floating-images.tsx",
        lineNumber: 42,
        columnNumber: 5
    }, this);
}
_s(FloatingSquares, "3LkfiWGtBEM8hKuM1fZoE6OzM7U=");
_c = FloatingSquares;
var _c;
__turbopack_context__.k.register(_c, "FloatingSquares");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/custom/floating-images.tsx [app-client] (ecmascript, next/dynamic entry)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/components/custom/floating-images.tsx [app-client] (ecmascript)"));
}),
]);

//# sourceMappingURL=src_components_custom_floating-images_tsx_8ea2fabb._.js.map